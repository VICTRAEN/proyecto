# rcedit – programmatic access to Research catalogue web interface
# (c)2021-2026 grrrr.org

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

__all__ = ['RCException', 'RCEdit']

import requests
from requests.auth import AuthBase
import re
import urllib
from html.parser import HTMLParser
import json
import time
from collections import defaultdict


class RCException(Exception):
    def __init__(self, reason=""):
        self.reason = reason
    def __repr__(self):
        return f'RCException("{self.reason}")'


class RCEdit:
    rcurl = "https://www.researchcatalogue.net"
    user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:153.0) Gecko/20100101 Firefox/153.0"

    def __init__(self, exposition):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": self.user_agent})
        self.exposition = exposition
        self.verbose = False


    def login(self, username, password):
        # we need to retrieve a cookie
        self._get("/auth/login")
        # now log in
        data = {'_username': username, '_password': password, '_csrf_token': "csrf-token"}
        rtext = self._post("/auth/login", data=data)


    def logout(self):
        self._get("/auth/logout")


    def info_get(self):
        rtext = self._get(f"/researches/{self.exposition}")
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("page_list failed")            
        info = self._InfoLister()(rtext)
        return info


    def meta_get(self):
        rtext = self._get(f"/expositions/{self.exposition}/edit")
        return self._ItemData()(rtext)


    def meta_set(self, title=None, description=None, **kwargs):

        data = {}
        if title is not None:
            data['metadata[title][en]'] = title
        if description is not None:
            data['metadata[description][en]'] = description
        data.update(kwargs)

        postdata = self.convert_params(dict(form=data))
        rtext = self._post(f"/expositions/{self.exposition}/edit", data=postdata)
        if rtext.strip() or self.last_response.headers.get('rc-form-status', '') != 'success':
            raise RCException("meta_set failed")


    def page_list(self, page_name=None, firstonly=False, regexp=False):
        "List pages (aka weaves), optionally filtered"
        
        # TODO: should we return id:(type,name) in _PageLister?
        # this would break backwards compatibility
        
        rtext = self._post(f"/editor/{self.exposition}/weaves")
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("page_list failed")            
        pages = self._PageLister()(rtext)
        
        if page_name is None:
            crit = lambda x: True
        else:
            if regexp:
                r = re.compile(page_name)
                crit = lambda x: r.match(x) is not None
            else:
                crit = lambda x: x == page_name
                
        pages = [(pid,pnm) for pid,pnm in pages.items() if crit(pnm)]
            
        if firstonly:
            return pages[0] if len(pages) else None
        else:
            return dict(pages)


    def page_add(self, page_name, page_type='graphical', description=None, iframe_url=None, **kwargs):
        # kwargs can be 'style' or 'meta' dicts

        # first step
        data = {"form[type][type]": page_type, "form[_buttons][next]": ""}
        rtext = self._post(f"/editor/{self.exposition}/new", data=data)
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("page_add failed")            

        data = {
            "meta[title]": page_name,
#            "meta[toc]": 0,
            "meta[description]": description if description is not None else "",        
        }

        # second step
        if page_type == 'graphical':
            data.update({
                # the lines not commented out are required
#                "style[font][fontFamily]": "'nimbus sans l', sans-serif",
#                "style[font][fontSize]": "",
#                "style[font][fontColor]": "",
#                "style[font][lineHeight]": "",
#                "style[margin][marginLeft]": "",
#                "style[margin][marginTop]": "",
#                "style[margin][marginRight]": "",
#                "style[margin][marginBottom]": "",
#                "style[padding][paddingLeft]": "",
#                "style[padding][paddingTop]": "",
#                "style[padding][paddingRight]": "",
#                "style[padding][paddingBottom]": "",
                "style[border][borderStyle]": "none",
#                "style[border][borderWidth]": "",
#                "style[border][borderColor]": "",
#                "style[border][borderRadius]": "",
#                "style[background][backgroundColor]": "",
#                "style[background][backgroundImage]": "",
                "style[background][_][backgroundImageStyle]": "repeat",
                "style[background][_][backgroundImagePosition]": "left top",
                "style[background][_][backgroundImageSize]": "auto",
#                "style[hyperlink][hyperlinkColor]": "",
#                "style[hyperlink][hyperlinkVisitedColor]": "",
#                "style[hyperlink][hyperlinkHoverColor]": "",
#                "style[popover][footnoteColor]": "",
#                "style[popover][footnoteVisitedColor]": "",
#                "style[popover][footnoteHoverColor]": "",
#                "style[rawCss][rawCss]": "",
#                "style[rawCss][expositionRawCss]": "",
            })
        elif page_type == 'block':
            data.update({
#                "style[font][fontFamily]": "'nimbus sans l', sans-serif",
#                "style[font][fontSize]": "",
#                "style[font][fontColor]": "",
#                "style[font][lineHeight]": "",
#                "style[background][backgroundColor]": "",
#                "style[hyperlink][hyperlinkColor]": "",
#                "style[hyperlink][hyperlinkVisitedColor]": "",
#                "style[hyperlink][hyperlinkHoverColor]": "",
#                "style[popover][footnoteColor]": "",
#                "style[popover][footnoteVisitedColor]": "",
#                "style[popover][footnoteHoverColor]": "",
#                "style[rawCss][rawCss]": "",
#                "style[rawCss][expositionRawCss]": ""
            })
        elif page_type == 'iframe':
            data.update({
                "meta[url]": iframe_url, # some valid URL must be given
            })
#        if description is not None:
#            data['meta[description][en]'] = description

        data.update(kwargs)
        data = self.convert_params({page_type: data})
        data.update({"_buttons[finish]": ""})

        postdata = self.convert_params(dict(form=data))
        rtext = self._post(f"/editor/{self.exposition}/new", data=postdata)
        if rtext.strip() or self.last_response.headers.get('rc-form-status', '') != 'success':
            raise RCException("page_add failed")

        m = re.match(r"/editor/\d+/(\d+)", self.last_response.headers["rc-form-redirect-on-success-url"])
        if m is None:
            raise RCException("page_add failed")
        page_id = m.group(1)
        return page_id


    def page_remove(self, page_id):
        data = {"form[_buttons][submit]": ""}
        rtext = self._post(f"/editor/{self.exposition}/{page_id}/delete", data=data)
        if rtext.strip():
            raise RCException("page_remove failed")


    def page_options_get(self, page_id):
        rtext = self._get(f"/editor/{self.exposition}/{page_id}/edit")
        return self._ItemData()(rtext)

    def page_options_set(self, page_id, **kwargs):
        """
        In kwargs, we need at least meta[title][en]
        """
        data = self.convert_params(dict(form=kwargs))

        rtext = self._post(f"/editor/{self.exposition}/{page_id}/edit", data=data)
        if rtext.strip():
            raise RCException("page_options_set failed")


    license_options = {
        "all-rights-reserved", "cc-by", "cc-by-sa", "cc-by-nc", "cc-by-nc-sa", "cc-by-nc-nd", "public-domain"        
    }

    
    mediaset_genres = {
        # publication
        'publication', 'paper', 'catalogue', 'article', 'book', 'broadcast', 'cd', 'dvd',
        # event 
        'event', 'exhibition', 'screening', 'concert', 'performance', 'festival', 'seminar', 
        'conference', 'presentation', 'workshop',
        # art object
        'art object', 'installation', 'scenery', 'piece', 'design', 'screenplay', 'sound', 
        'photograph', 'painting', 'scale model', 'digital artwork', 'visualisation', 'illustration', 
        'ceramic', 'print', 'construction', 'drawing', 'video', 'composition', 'movie',
    }


    def mediaset_list(self, mediaset_name=None, firstonly=False, regexp=False):
        "List media sets (aka works), optionally filtered"
        rtext = self._get(f"/editor/{self.exposition}/works")
        mediasets = self._SetLister()(rtext) # {set_id: set_name, ...}

        if mediaset_name is None:
            crit = lambda x: True
        else:
            if regexp:
                r = re.compile(mediaset_name)
                crit = lambda x: r.match(x) is not None
            else:
                crit = lambda x: x == mediaset_name
                
        mediasets = [(msid,msnm) for msid,msnm in mediasets.items() if crit(msnm)]
            
        if firstonly:
            return mediasets[0] if len(mediasets) else None
        else:
            return dict(mediasets)


    def mediaset_find(self, ):
        "Find media set by name"
        raise NotImplementedError()


    def mediaset_add(self, mediaset_name, mediaset_description=""):
        "Add new media set"

        data = dict(title=mediaset_name, description=mediaset_description)
        rtext = self._post("/api/sets", data=data)
        lst = json.loads(rtext)
        mediaset_id = lst['id']
        return mediaset_id


    def mediaset_remove(self, mediaset_id):
        "Remove media set"
        rtext = self._delete(f'/api/sets/{mediaset_id}')
        lst = json.loads(rtext)
        if lst != {}:
            raise RCException("mediaset_remove failed")


    media_types = {'image', 'audio'}


    def media_list(self, mediaset_id=None, media_name=None, media_type=None, firstonly=False, regexp=False):
        # as of 2021-12, one must provide a weave ID
        # for now, we simply take the first page of the exposition
        # since media should be shared among all pages
        pages = list(self.page_list())
        if mediaset_id is None:
            # from simple-media
            rtext = self._post(f"/editor/{self.exposition}/{pages[0]}/simple-medias")
            media = self._SimpleMediaLister()(rtext)
        else:
            rtext = self._post(f'/editor/{self.exposition}/{pages[0]}/works/{mediaset_id}/children')
            lst = json.loads(rtext)
            media = {str(f['id']): (f['tool'], f['title']) for f in lst['files']}

        if media_name is None:
            critn = lambda n: True
        else:
            if regexp:
                r = re.compile(media_name)
                critn = lambda n: r.match(n) is not None
            else:
                critn = lambda n: n == media_name
            
        if media_type is None:
            critt = lambda t: True
        else:
            critt = lambda t: t == media_type
            
        media = [(mid,(mtp,mnm)) for mid,(mtp,mnm) in media.items() if critn(mnm) and critt(mtp)]
        
        if firstonly:
            return media[0] if len(media) else None
        else:
            return dict(media)


    def media_add(self, media_name, copyrightholder, media_type='image', license="cc-by-nc", description='', mediaset_id=None):
        "Add media file to simple-media or set"

        if mediaset_id is not None:
            raise NotImplementedError("Adding media to mediasets not supported")

        if media_type not in self.media_types:
            raise RCException(f"Media type '{media_type}' not valid")
                  
        if license not in self.license_options:
            raise RCException(f"License '{license}' not valid")

        data = {'form[type][type]': media_type, 'form[_buttons][next]': ""}
        self._post(f"/researches/{self.exposition}/simple-medias/new", data=data)
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("media_add failed")            

        data = {
            'name': media_name,
            'copyrightHolder': copyrightholder,
            'license': license,
            'description': description,
#            'ariaLabel': '',
        }
        data = self.convert_params({media_type: data})
        data.update({"_buttons[finish]": ""})
        postdata = self.convert_params(dict(form=data))
        rtext = self._post(f"/researches/{self.exposition}/simple-medias/new", data=postdata)

        if self.last_response.headers.get('rc-form-status', '') != 'success':
            raise RCException("media_add failed")

        url = self.last_response.headers['rc-form-url']
        m = re.match(r"/researches/\d+/simple-medias/(\d+)/edit", url)
        if m is None:
            raise RCException("media_add failed")
        media_id = m.group(1)
        return media_id


    def media_remove(self, media_id, mediaset_id=None):
        if mediaset_id is not None:
            raise NotImplementedError("Removing media from mediasets not supported")

        data = {
            'form[selection][]': media_id,
            'form[_buttons][submit]': '',
        }
        rtext = self._post(f'/researches/{self.exposition}/simple-medias/delete', data=data)
        if rtext.strip() or self.last_response.headers.get('rc-form-status', '') != 'success':
            raise RCException("media_remove failed")


    def media_upload(self, media_id, filename):
        if filename.endswith('.png'):
            mimetype = 'image/png'
            mediatype = 'image'
        elif filename.endswith('.gif'):
            mimetype = 'image/gif'
            mediatype = 'image'
        elif filename.endswith('.svg'):
            mimetype = 'image/svg+xml'
            mediatype = 'image'
        elif filename.endswith('.tif') or filename.endswith('.tiff'):
            mimetype = 'image/tiff'
            mediatype = 'image'
        elif filename.endswith('.jpg') or filename.endswith('.jpeg'):
            mimetype = 'image/jpeg'
            mediatype = 'image'
        elif filename.endswith('.mp3'):
            mimetype = 'audio/mpeg'
            mediatype = 'audio'
        elif filename.endswith('.wav'):
            mimetype = 'audio/wave'
            mediatype = 'audio'
        else:
            raise ValueError('File type unknown')

        with open(filename, 'rb') as f:
            files = {f"form[{mediatype}][media]": (filename, f, mimetype)}

            rtext = self._post(f"/researches/{self.exposition}/simple-medias/{media_id}/edit", files=files)
            if rtext.strip() or self.last_response.headers.get('rc-form-status', '') != 'success':
                raise RCException("media_upload failed")


    def item_list(self, page_id, item_name=None, item_type=None, firstonly=False, regexp=False):
        "List items on page (aka weave), optionally filtered"
        rtext = self._post(f"/editor/{self.exposition}/{page_id}/content")
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("page_list failed")            
        items = self._ItemLister()(rtext)

        if item_name is None:
            critn = lambda n: True
        else:
            if regexp:
                r = re.compile(item_name)
                critn = lambda n: r.match(n) is not None
            else:
                critn = lambda n: n == item_name

        if item_type is None:
            critt = lambda t: True
        else:
            critt = lambda t: t == item_type
                
        items = [(itid,(ittp,itnm)) for itid,(ittp,itnm) in items.items() if critn(itnm) and critt(ittp)]
            
        if firstonly:
            return items[0] if len(items) else None
        else:
            return dict(items)


    def item_find(self, page_id, item_name, item_type=None, firstonly=True):
        "Find item by name (either item_name or item_type may be None, indicating 'any')"
        items = [
            iid for iid,(itp,inm) in self.item_list(page_id).items() 
            if (item_name is None or inm == item_name) and (item_type is None or itp == item_type)
        ]
        if firstonly:
            return items[0] if len(items) else None
        else:
            return items


    def item_add(self, page_id, tool, x, y, w, h):
        """
        Add item to page (aka weave)
        'tool' can be "simpletext", "text", "picture", "audio", "video", "slideshow", "pdf", "shape"
        """
        data = dict(toolType=tool, left=x, top=y, width=w, height=h)
        rtext = self._post(f'/editor/{self.exposition}/{page_id}/tools/new', data=data)
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("item_add failed")            

        # TODO: we should use HTML parsing
        m = re.search(r'data-id="(\d+)"', rtext)
        if m is None:
            raise RCException("item_add failed")
        item_id = m.group(1)
        return item_id


    def item_update(self, page_id, item_id, x, y, w, h, r=0):
        "Fast item positioning update"
        data = dict(left=x, top=y, width=w, height=h, rotate=r)
        data = self.convert_params({f'data[{item_id}]': data})
        rtext = self._post(f'/editor/{self.exposition}/{page_id}/tools/update', data=data)
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("item_update failed")            
        # we could parse for the data-id attribute


    def item_lock(self, page_id, item_id, lock=True):
        data = {f'data[{item_id}][lock]': 1 if lock else 0}
        rtext = self._post(f'/editor/{self.exposition}/{page_id}/tools/update', data=data)
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("item_lock failed")            
        # we could parse for data-id and data-locked attributes


    def item_get(self, page_id, item_id):
        rtext = self._get(f"/editor/{self.exposition}/{page_id}/tools/{item_id}/edit")
        if not self.last_response.headers.get('content-type', 'text/html').startswith('text/html'):
           raise RCException("item_get failed")            
        return self._ItemData()(rtext)


    def item_set(self, page_id, item_id, **kwargs):
        """
        In kwargs, we need at least common[title] and style[top,left,width,height,rotate]
        """
        data = self.convert_params(dict(form=kwargs))
        rtext = self._post(f"/editor/{self.exposition}/{page_id}/tools/{item_id}/edit", data=data)
        if rtext.strip() or self.last_response.headers.get('rc-form-status', '') != 'success':
            raise RCException("item_set failed")


    def item_remove(self, page_id, item_id):
        "Remove item from page (aka weave)"
        data = {'selection[]': item_id, '_buttons[submit]': ''}
        data = self.convert_params(dict(form=data))
        rtext = self._post(f"/editor/{self.exposition}/{page_id}/tools/delete", data=data)
        if rtext.strip() or self.last_response.headers.get('rc-form-status', '') != 'success':
            raise RCException("item_remove failed")


    #### internal methods #####################################################

    @staticmethod
    def _chk_attr(attrs, attr, val):
        for a,d in attrs:
            if a == attr and d == val:
                return True
        return False


    class _InfoLister(HTMLParser):
        def __call__(self, html):
            self.items = {}
            self.key = None
            self.found = set()
            self.feed(html)
            return self.items

        def handle_starttag(self, tag, attrs):
            if \
                (tag == 'table' and RCEdit._chk_attr(attrs, 'class', 'meta-table')) or \
                ('table' in self.found and tag in ('th', 'td')):
                self.found.add(tag)

        def handle_endtag(self, tag):
            if tag in ('td', 'th') and tag in self.found:
                self.found.remove(tag)

        def handle_data(self, data):
            if 'th' in self.found:
                self.key = data
                self.items[self.key] = ""
            elif 'td' in self.found:
                self.items[self.key] += data
 

    class _PageLister(HTMLParser):
        def __call__(self, html):
            self.items = {}
            self.nest_tr = 0
            self.feed(html)
            return self.items

        def handle_starttag(self, tag, attrs):
            if tag == 'tr':
                self.nest_tr += 1
                if self.nest_tr == 1:
                    self.nest_td = 0
                    self.cnt_td = 0
                    attrs = dict(attrs)
                    try:
                        self.item = attrs['data-id']
                    except:
                        pass
            elif tag == 'td' and self.nest_tr == 1:
                self.nest_td += 1
                self.cnt_td += 1

        def handle_endtag(self, tag):
            if tag == 'tr':
                self.nest_tr -= 1
            elif tag == 'td' and self.nest_tr == 1:
                self.nest_td -= 1

        def handle_data(self, data):
            if self.nest_tr == 1:
                pos = (self.nest_td, self.cnt_td)
                # pos == (1,1): type (graphical, block, iframe)
                # pos == (1,2): title
                # pos == (1,3): date
                if pos == (1,2):
                    self.items[self.item] = data


    class _SetLister(HTMLParser):
        def __call__(self, html):
            self.items = {}
            self.nest_tr = 0
            self.feed(html)
            return self.items

        def handle_starttag(self, tag, attrs):
            if tag == 'tr':
                self.nest_tr += 1
                if self.nest_tr == 1:
                    self.nest_td = 0
                    self.cnt_td = 0
                    attrs = dict(attrs)
                    try:
                        if attrs['class'] == 'work':
                            self.item = attrs['data-id']
                    except:
                        pass
            elif tag == 'td' and self.nest_tr == 1:
                self.nest_td += 1
                self.cnt_td += 1

        def handle_endtag(self, tag):
            if tag == 'tr':
                self.nest_tr -= 1
            elif tag == 'td' and self.nest_tr == 1:
                self.nest_td -= 1

        def handle_data(self, data):
            if self.nest_tr == 1 and self.nest_td == 1 and self.cnt_td == 2:
                self.items[self.item] = data


    class _SimpleMediaLister(HTMLParser):
        def __call__(self, html):
            self.items = {}
            self.nest_tr = 0
            self.feed(html)
            return self.items

        def handle_starttag(self, tag, attrs):
            if tag == 'tr':
                self.nest_tr += 1
                if self.nest_tr == 1:
                    self.nest_td = 0
                    self.cnt_td = 0
                    attrs = dict(attrs)
#                    print(tag, attrs)
                    try:
                        if 'simple-media' in attrs['class'].split():
                            self.item = attrs['data-id']
                            self.tool = attrs['data-tool']
                    except:
                        pass
            elif tag == 'td' and self.nest_tr == 1:
                self.nest_td += 1
                self.cnt_td += 1

        def handle_endtag(self, tag):
            if tag == 'tr':
                self.nest_tr -= 1
            elif tag == 'td' and self.nest_tr == 1:
                self.nest_td -= 1

        def handle_data(self, data):
            if self.nest_tr == 1 and self.nest_td == 1 and self.cnt_td == 2:
                self.items[self.item] = (self.tool, data)


    class _ItemLister(HTMLParser):
        def __call__(self, html):
            self.items = {}
            self.feed(html)
            return self.items

        def handle_starttag(self, tag, attrs):
            if tag == 'div':
                attrs = dict(attrs)
                try:
                    self.items[attrs['data-id']] = (attrs['data-tool'], attrs['data-title'])
                except:
                    pass


    class _ItemData(HTMLParser):
        toolmatch = re.compile(r'edit\s*([^\s]+)\s*tool')
        bracketmatch = re.compile(r'([^\[]*)\[([^\]]*)\]((\[[^\]]*\])*)$')
        
        def __call__(self, html):
            self.title = None
            self.data = defaultdict(dict)
            self.select = None
            self.textarea = None
            self.required = None
            self.feed(html)
            return self.title, self.data['form']

        def handle_starttag(self, tag, attrs):
            attrs = dict(attrs)
 
            if tag =='form':
                try:
                    m = self.toolmatch.match(attrs['title'])
                except KeyError:
                    m = None
                if m is not None:
                    self.title = m.group(1)

            elif tag == 'input':
                tp = attrs.get('type', 'text')
                self.required = attrs.get('required', None) is not None
                m = self.bracketmatch.match(attrs['name'])
                v = None
                if m is not None:
                    if (tp != 'checkbox' or "checked" in attrs) and tp != 'file':
                        try:
                            v = attrs['value']
                        except:
                            if tp == 'number':
                                v = attrs.get('min', 0)
                            else:
                                v = "" # if self.required else None
                    vk = m.group(2)
                    if m.group(3) is not None:
                        vk += m.group(3)

                    if v is not None:
                        try:
                            lv = self.data[m.group(1)][vk]
                        except KeyError:
                            lv = None
                        lv = self.collect_options(lv, v, True)
                        self.data[m.group(1)][vk] = lv
 
            elif tag == 'select':
                try:
                    attr_name = attrs['name']
                except KeyError:
                    pass
                else:
                    m = self.bracketmatch.match(attr_name)
                    if m is not None:
                        self.select = (m.group(1),m.group(2)+(m.group(3) if m.group(3) is not None else ""))
                self.required = attrs.get('required', None) is not None
                self.select_multi = 'multiple' in attrs  # appearence counts independent of the value
                self.option_sel = 0
            elif tag == 'option' and self.select is not None:
                v = attrs['value']

                # fetch existing (partial) value
                try:
                    lv = self.data[self.select[0]][self.select[1]]
                except KeyError:
                    lv = None

                if lv is None and not self.select_multi:
                    # remember first option (if we have no other selected one at the end)
                    lv = v

                if 'selected' in attrs:
                    if not self.option_sel:
                        lv = None # delete first option if there was no selection
                    lv = self.collect_options(lv, v, self.select_multi)
                    self.option_sel += 1

                if lv is None and self.required:
                    lv = ""

                if lv is not None:
                    # store value
                    self.data[self.select[0]][self.select[1]] = lv

            elif tag == 'textarea':
                m = self.bracketmatch.match(attrs['name'])
                if m is not None:
                    vk = m.group(2)
                    if m.group(3) is not None:
                        vk += m.group(3)
                    self.textarea = (m.group(1),vk)
            
        def handle_data(self, data):
            if self.textarea is not None:
                self.data[self.textarea[0]][self.textarea[1]] = data
                self.textarea = None

        def handle_endtag(self, tag):
            if tag == 'select':
                self.select = None
            elif tag == 'textarea':
                pass #self.textarea = None

        @staticmethod
        def collect_options(lv, v, multi=True):
            if multi:
                # collect all options
                if lv is None:
                    lv = v
                else:
                    try:
                        # if it is already a list, just add
                        lv.append(v)
                    except:
                        # if it is not a list, make one
                        lv = [lv, v]
            else:                        
                # take last appearing option
                lv = v
            return lv


    def _post(self, url, data=None, files=None, json=None, headers=None):
        if self.verbose:
            print("POST", url, data)
        r = self.session.post(f"{self.rcurl}{url}", data=data, files=files, json=json, headers=headers)
        self.last_response = r
        if r.status_code != 200:
            raise RCException(f'POST {url} failed with status code {r.status_code}')
        return r.text


    def _get(self, url, params=None, headers=None):
        if self.verbose:
            print("GET", url, params)
        r = self.session.get(f"{self.rcurl}{url}", params=params, headers=headers)
        self.last_response = r
        if r.status_code != 200:
            raise RCException(f'GET {url} failed with status code {r.status_code}')
        return r.text


    def _delete(self, url, headers=None):
        if self.verbose:
            print("DELETE", url)
        r = self.session.delete(f"{self.rcurl}{url}", headers=headers)
        self.last_response = r
        if r.status_code != 200:
            raise RCException(f'DELETE {url} failed with status code {r.status_code}')
        return r.text


    subkeymatch = re.compile(r'([^\[]+)((\[[^\]]*\])*)') # matches "key[value][...]"

    @staticmethod
    def convert_params(kwargs):
        data = dict()
        for kk, kv in kwargs.items():
            for k,v in kv.items():
                m = RCEdit.subkeymatch.match(k)
                if m is None:
                    data[f'{kk}[{k}]'] = v
                else:
                    data[f'{kk}[{m.group(1)}]{m.group(2)}'] = v
        return data
